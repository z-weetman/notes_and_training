# Databricks notebook source
# MAGIC %md
# MAGIC # Section three - Data reporting and visualisation

# COMMAND ----------

# MAGIC %md
# MAGIC Goals of this section are to:
# MAGIC
# MAGIC - Create visualisations in notebooks and SQL Editor
# MAGIC - Create a dashboard with a schedule and notifications
# MAGIC - Create a connection to powerBI to visualise your data there
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Visualisation in Notebooks and SQL Editor

# COMMAND ----------

# MAGIC %md
# MAGIC Let's try and make a chart in a notebook. 
# MAGIC
# MAGIC Step 1: Get some data 
# MAGIC
# MAGIC Step 2: click the + button and select visualisation If we run a query or code that makes a table/dataframe, we can then present it

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from suppanwo.supplydatateam.all_store_details

# COMMAND ----------

# MAGIC %md
# MAGIC Now let's try the same query and chart in SQL editor. 
# MAGIC
# MAGIC Copy the query above and nagivate to "SQL Editor" in the left hand pane. 
# MAGIC Open a new query and paste in the query syntax.
# MAGIC Make sure a compute option is available and click "Run" in the blue box.

# COMMAND ----------

# MAGIC %md
# MAGIC Once the query is run, we are able to click the "+" button and select "Visualization". Here we can then make the same chart as above!

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/sql_editor.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC ## Dashboards
# MAGIC Dashboards are a great way of presenting and visualising a lot of information in a concise way
# MAGIC
# MAGIC Here is an example Retail Revenue & Supply Chain Overview dashboard
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://docs.databricks.com/en/_images/lakeview-published-sample-retail.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC To get started with Dashboards click the "Dashboards" section in the menu on the left
# MAGIC
# MAGIC We have two types of dashboards currently - Dashboards and Legacy Dashboards. 
# MAGIC
# MAGIC Dashboards have lots much features and functionality so we recommend anything new to be build as a Dashboard rather than lecacy one.

# COMMAND ----------

# MAGIC %md
# MAGIC Once on the dashboards page we can start making one. 
# MAGIC
# MAGIC Rather than finding any data to play with, we can use some prepared dashboards. 
# MAGIC
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Dashboards.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC Next to the "Create dashboard" button, select the "View samples gallery", click "Retail Revenue & Supply Chain Overview" and import.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC The dashboard should popup!
# MAGIC
# MAGIC To add filtes, charts, and parameters, there is a blue menu at the bottom of the page
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/vis_dashboard_button.png" alt="Databricks Learning" style="object-fit:scale-down;width:10px;height:10px;">
# MAGIC </div>
# MAGIC
# MAGIC Click through the options and try to make a chart yourself.
# MAGIC
# MAGIC If you aren't wanting to select all the options, you can use the AI feature to write in english what you want to visualise and it will create it for you - it also offers some suggestions:
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Dashboard_ai.png" alt="Databricks Learning" style="object-fit:scale-down;width:10px;height:10px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Connecting to powerBI
# MAGIC
# MAGIC When you use Databricks as a data source with Power BI, you can bring the advantages of Databricks performance and technology beyond data scientists and data engineers to all business users. 
# MAGIC
# MAGIC We'll start by connecting Power BI Desktop to a Databricks SQL Warehouse and selecting the relevant data to report on. 
# MAGIC
# MAGIC 1. Open Power BI Desktop (alway a good idea to have a recent version), navigate to Get Data and select Azure Databricks, then Connect.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_get_data.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:10px;height:10px;">
# MAGIC </div>
# MAGIC
# MAGIC 2. In the next screen, the main bits you need to fill in in order to connect to Databricks are the **Server Hostname** (telling Power BI which Databricks workspace to connect to) and the **HTTP Path** (telling Power BI which SQL Warehouse in that Databricks workspace to use). It can be a good idea to also specify the **catalog** and the **schema** to help simplify the data exploration, depending on the use case. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_connection_screen.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>
# MAGIC
# MAGIC 3. In order to obtain the **Server Hostname** and **HTTP Path**, navigate to the Databricks platform, select SQL Warehouses in the menu on the left, then select the Warehouse you wish to connect to. Once on it, select the Connection details tab and you should see the information you need. Copy the Server Hostname and HTTP Path and paste them in the Power BI screen.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_server_host.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>
# MAGIC
# MAGIC 4. Before pressing **OK** in Power BI and connecting to Databricks, you should decide if you wish to use **Import** or **Direct Query** and the Data Connectivity Mode. If using Import, a data refresh may have to be created and scheduled in order to keep the data fresh. 
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_extract_type.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>
# MAGIC
# MAGIC 5. The next step is to authenticate from Power BI Desktop to Databricks SQL. You will only need to do this ocasionaly, as Power BI will cache the credentials for ease of use. You can use Azure Active Directory - renamed to Microsoft Entra recently (prefered) or Personal Access Token for this. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_authenticate.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>
# MAGIC
# MAGIC 6. Once succesfully authenticate, you will see a Navigator screen where you can navigate the various catalogs and schemas you have access to and select the tables and views you wish to include in the report. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_select_data.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>
# MAGIC
# MAGIC 7. Once you hit **load** and the load completes, you can start interacting with the Databricks data using Power BI's full capabilities. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Pbi_dataset.png" alt="Power BI Get Data from Databricks" style="object-fit:scale-down;width:6px;height:6px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC