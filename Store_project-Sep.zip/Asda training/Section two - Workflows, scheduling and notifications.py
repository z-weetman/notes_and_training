# Databricks notebook source
# MAGIC %md
# MAGIC # Section two - Workflows, schedules and notifications

# COMMAND ----------

# MAGIC %md
# MAGIC Goals of this section are to:
# MAGIC
# MAGIC 1. Building a workflow that ingests data, combines different tables together and runs some queries to find the answers to our business questions: 
# MAGIC
# MAGIC - Which store doesn’t open on Sundays?
# MAGIC - Which store has the highest revenue? Does this correlate with SqFt?
# MAGIC - How does revenue track for A1 this year? 
# MAGIC
# MAGIC 2. Look at options for notifications
# MAGIC
# MAGIC There are numerous ways to send notifications like emails to make recipients aware of status updates such as job success, alert triggers, pipeline failures. We will focus on workflows in this section.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Workflows

# COMMAND ----------

# MAGIC %md
# MAGIC Step 1: Nagivate to Workflows (on the left menu)
# MAGIC
# MAGIC Step 2: Click "Create Job" (Blue button on the top right)
# MAGIC
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Workflows_home.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC There should now be a new window that has a new task
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/workflows.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC Step 3: Enter the details of your new workflow
# MAGIC
# MAGIC - Give your task a name - perhaps Workflow notebook example
# MAGIC - Select "Notebook" as the type
# MAGIC - Source is "Workspace"
# MAGIC - Path - Navigate to this notebook to the "Workflow" folder in the workspace. Add a new task for the "Ingest our csv data" notebook in the folder
# MAGIC - Compute - Use the personal compute that we are currently using
# MAGIC
# MAGIC Step 4: check your details and click "Create Task" button at the bottom
# MAGIC
# MAGIC Great job - You've made your first Workflow task!

# COMMAND ----------

# MAGIC %md
# MAGIC Let's add some more tasks to our workflow.
# MAGIC
# MAGIC Add the "Ingest excel data" notebook as a new task. Here make sure that it has the personal compute with out library attached.
# MAGIC Also make sure to remove the dependency on the first task - dependencies aren't needed for this stage!
# MAGIC
# MAGIC For the next task, add "join source data", and display both ingest options as dependencies in "depends on" section 
# MAGIC
# MAGIC Finally add the "Query the data" notebook. This runs a few queries on the data we've ingested and processed.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/workflow_stores.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Let's run!
# MAGIC
# MAGIC Rename your workflow (click at the top where it says "New job" and the date/time and give it a better name)
# MAGIC
# MAGIC At the top right there is a "Run now" button in blue - let's give it a run!

# COMMAND ----------

# MAGIC %md
# MAGIC ## Review the run
# MAGIC At the top click the "Runs" tab (We have been on the "Tasks" tab).
# MAGIC
# MAGIC Runs shows you the recent runs for this workflow. It shows details like length of time, success/failure as well as the output details.
# MAGIC
# MAGIC Have a look around this page to see how your workflow ran - did it fail? Why? Did it succeed? How long did it take?

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/workflow_runs.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scheduling and notifications
# MAGIC Now we have a workflow, let's look to schedule it and get it to send us an email when it finishes. 
# MAGIC
# MAGIC On the right hand side there is a "Job details" panel, if this is closed, expand it using the arrow. This shows details on how the workflow is running, what permissions it uses, when it runs, permissions and notifications.
# MAGIC
# MAGIC Scroll down to "Schedules & Triggers" and Add Trigger. 
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Schedule_workflow.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC
# MAGIC Enter the trigger details:
# MAGIC - Trigger type as "Scheduled"
# MAGIC - Schedule Type as "Advanced"
# MAGIC - Enter a time that starts in five minutes or so
# MAGIC
# MAGIC Click Save - now we have 5 minutes to set up notifications!
# MAGIC
# MAGIC Scroll further down on the Job Details pane, to Job Notifications > "Edit Notifications">"Add Notification"
# MAGIC
# MAGIC A new row will pop up - enter destination as "Email Address" and add your email. Select the boxes "Success" and "Failure" so we get notified if it runs regardless of the outcome. Click Save.
# MAGIC
# MAGIC Now we wait to see if we get an email!
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC We've managed to build a workflow, review the run and set a schedule that notifies recipients of job completion!
# MAGIC
# MAGIC Have a play adding more tasks and schedules - once done, don't forget to tidy up!

# COMMAND ----------

# MAGIC %md
# MAGIC