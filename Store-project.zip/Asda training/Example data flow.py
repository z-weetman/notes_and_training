# Databricks notebook source
# MAGIC %md
# MAGIC ## Asda Introductory workshop
# MAGIC This notebook walks through:
# MAGIC
# MAGIC
# MAGIC Finding, connecting and querying data
# MAGIC -   Reading data from a managed or external table in Unity Catalog
# MAGIC -   Working with volumes - reading from csv & excel
# MAGIC -   Federated data access - Synapse
# MAGIC
# MAGIC
# MAGIC Workflows, scheduling and notifications 
# MAGIC -   Building a workflow
# MAGIC - Scheduling a workflow
# MAGIC -   Sending email alerts out
# MAGIC
# MAGIC
# MAGIC Visualising Data
# MAGIC - Dashboarding and Genie
# MAGIC - Connecting to powerBI

# COMMAND ----------

# MAGIC %md
# MAGIC ### Getting started - Set up Cluster!

# COMMAND ----------

# MAGIC %md
# MAGIC Cluster set up - today we are going to be using personal clusters
# MAGIC 14.3LTS support cluster

# COMMAND ----------

# MAGIC %md
# MAGIC To setup a personal cluster, nagivate to the "Compute" section on the left handside
# MAGIC
# MAGIC In the new Compute window, click "Create Compute"
# MAGIC
# MAGIC Make sure it is assigned to your user and has a Databricks Runtime of 14.3LTS

# COMMAND ----------

# MAGIC %md
# MAGIC # Section one - Working with Unity catalog

# COMMAND ----------

# MAGIC %md
# MAGIC Find and open the notebook - ./Section one - Working with UC

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Section Two - Workflows, scheduling and notifications

# COMMAND ----------

# MAGIC %md
# MAGIC %md
# MAGIC Find and open the notebook - ./Section two - workflows, scheduling and notifications

# COMMAND ----------

# MAGIC
# MAGIC %md
# MAGIC # Section Three - Workflows, scheduling and notifications
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Find and open the notebook - ./Section three - Data reporting and visualisation