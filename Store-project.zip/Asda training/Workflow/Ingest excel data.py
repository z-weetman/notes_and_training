# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog suppanwo;
# MAGIC use schema supplydatateam;

# COMMAND ----------

volume_path = "/Volumes/suppanwo/supplydatateam/datasupply/"

# COMMAND ----------

df_xlsx = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("dataAddress", "'Sheet1'!A1")  \
    .option("treatEmptyValuesAsNulls", "true") \
    .load(volume_path + "Store_characteristics.xlsx")
display(df_xlsx)

# COMMAND ----------

df_xlsx.write.mode("overwrite").format("delta").saveAsTable("store_characteristics")