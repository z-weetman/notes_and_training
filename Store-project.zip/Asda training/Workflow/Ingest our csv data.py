# Databricks notebook source
# MAGIC %md
# MAGIC Specify location in UC

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog suppanwo;
# MAGIC use schema supplydatateam;

# COMMAND ----------

# MAGIC %md
# MAGIC Run volume path

# COMMAND ----------

volume_path = "/Volumes/suppanwo/supplydatateam/datasupply/"

# COMMAND ----------

# MAGIC %md
# MAGIC Load in store_revenue csv

# COMMAND ----------

df = spark.read.csv(volume_path + "store_revenue.csv", header=True, inferSchema=True)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC Save store revenue into UC

# COMMAND ----------

df.write.mode("overwrite").format("delta").saveAsTable("store_revenue")