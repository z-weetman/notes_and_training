# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC ## Reading and writing to Data in Unity catalog
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Unity Catalog
# MAGIC
# MAGIC Unity Catalog provides centralized access control, auditing, lineage, and data discovery capabilities across Databricks workspaces.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://docs.databricks.com/en/_images/with-unity-catalog.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC
# MAGIC ## Three level name space
# MAGIC Unlike other databases/data stores, Unity Catalog nests tables under a schema and a catalog, this means there are three levels so we call it a three level name space!
# MAGIC
# MAGIC This means when you are reading or writing to UC you need to specify the catalog, schema and table name. 
# MAGIC Catalog is the highest level, you can see this as a directory.
# MAGIC Schema is similar to a database and this is the second level.
# MAGIC The final level is where your tables and volumes sit - we will come to volumes shortly
# MAGIC
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://docs.databricks.com/en/_images/object-model.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC This means we need to use the three levels - catalog, schema and table when working with out data
# MAGIC
# MAGIC
# MAGIC When writing a query, it looks something like this:
# MAGIC
# MAGIC SELECT * FROM catalog.schema.table

# COMMAND ----------

# MAGIC %md
# MAGIC ## Using the UI to find data

# COMMAND ----------

# MAGIC %md
# MAGIC Clicking "Catalog" on the left hand side menu will take you to the catalog list. You can list all catalogs you have access to, or look at your recents or favourites.
# MAGIC
# MAGIC Look into a catalog and then schema. From there you'll see your tables where you can get sample data, permission information, lineage and table structure. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/catalog_explorer.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC Explore some of the catalogs and schemas you have access to to see what your data looks like!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Examples!
# MAGIC Let's try accessing our first query

# COMMAND ----------

# MAGIC %md
# MAGIC Set the Schema

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog suppanwo;
# MAGIC use schema supplydatateam;

# COMMAND ----------

# MAGIC %md
# MAGIC Create a table in unity catalog.
# MAGIC This will go into the catalog and schema we have set above

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE or replace TABLE sample_data (
# MAGIC   ID bigint,
# MAGIC   item_type string,
# MAGIC   Colour string,
# MAGIC   Category string,
# MAGIC   Pattern_type string
# MAGIC ) USING DELTA;
# MAGIC
# MAGIC INSERT INTO sample_data VALUES
# MAGIC   (1, 'T-Shirt', 'Red', 'Casual', 'Solid'),
# MAGIC   (2, 'Pants', 'Blue', 'Formal', 'Striped'),
# MAGIC   (3, 'Dress', 'Green', 'Evening', 'Polka Dot');

# COMMAND ----------

# MAGIC %md
# MAGIC Now if we look in the catalog and schema we can see that there is a new table created!
# MAGIC
# MAGIC Let's try to read from it!
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample_data
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Creating a view

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE VIEW sample_data_view AS
# MAGIC SELECT * FROM sample_data;

# COMMAND ----------

# MAGIC %md
# MAGIC Let's test the view

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from sample_data_view

# COMMAND ----------

# MAGIC %md
# MAGIC ### Multi-language
# MAGIC Let's try this in python!

# COMMAND ----------

# List tables in catalog suppanwo and schema supplydatateam
tables_schema = spark.sql("SHOW TABLES IN suppanwo.supplydatateam")
display(tables_schema)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Volumes
# MAGIC Let's try working with CSV and Excels!
# MAGIC For csv and xlsx we are going to switch to python...which we can do in the same notebook!
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC We have a volume in catalog.schema: **suppanwo.supplydatateam** called **datasupply**
# MAGIC
# MAGIC Let's add some new files and try reading them in. 

# COMMAND ----------

# MAGIC %md
# MAGIC **Placing a file in Blob storage**
# MAGIC
# MAGIC Navigate to the bucket/blob container where your volume points to. 
# MAGIC Upload a file to the storage area. Now if we look at volumes in Unity catalog - we should be able to see and use the file you just placed!
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Below is an example of reading in a csv file from a volume

# COMMAND ----------

volume_path = "/Volumes/suppanwo/supplydatateam/datasupply/"

# COMMAND ----------

df = spark.read.csv(volume_path + "store_revenue.csv", header=True, inferSchema=True)
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###  Now let's try writing to a csv

# COMMAND ----------

# MAGIC %md
# MAGIC This method stores the metadata of the writes:

# COMMAND ----------

df.coalesce(1).write.mode("overwrite").csv(volume_path + "test_write.csv", header=True)

# COMMAND ----------

# MAGIC %md
# MAGIC This method is only really suitable for smaller datasets but will store it in a more traditional method for users working with csvs:

# COMMAND ----------

df.toPandas().to_csv(volume_path + "test_write2.csv", index=False, header=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Now let's try with excel
# MAGIC
# MAGIC
# MAGIC Excel is a harder format to read so there are a couple more steps involved.
# MAGIC Firstly we need to load a python library - this is quick and easy and good practice for any other libraries you may need in the future!

# COMMAND ----------

# MAGIC %md
# MAGIC To add a library:
# MAGIC 1. Navigate to the "compute" section in the menu on the left hand side
# MAGIC 2. Select the cluster you are using
# MAGIC 3. Select the Libraries tab under the cluster name
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Add_library.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC 4. Select the blue button "Install Library". An installation will popup. There are many options depending on what type of library you want to install but for today we are going to use Maven
# MAGIC
# MAGIC 5. Select "Search Packages". A new box will pop up. Select Maven central rather than Spark packages
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/import_library.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC 6. Search for crealytics and select the one matching "com.crealytics:spark-excel_2.12:3.5.1_0.20.4" - note this may have changed since time of writing
# MAGIC
# MAGIC 7. Click install
# MAGIC
# MAGIC This will now attach to the cluster - note that if the cluster is not running, it will be added during cluster bootup 
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC Now we are ready to read an excel!

# COMMAND ----------

df_xlsx = spark.read.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("inferSchema", "true") \
    .option("dataAddress", "'Sheet1'!A1")  \
    .option("treatEmptyValuesAsNulls", "true") \
    .load(volume_path + "Store_characteristics.xlsx")
display(df_xlsx)

# COMMAND ----------

# MAGIC %md
# MAGIC All done!
# MAGIC Now let's write back to excel

# COMMAND ----------

df_xlsx.write.format("com.crealytics.spark.excel") \
    .option("header", "true") \
    .option("dataAddress", "'Sheet1'!A1") \
    .mode("overwrite") \
    .save(volume_path + "example_write_file.xlsx")

# COMMAND ----------

# MAGIC %md
# MAGIC Let's save it to UC

# COMMAND ----------

df_xlsx.write.format("delta").saveAsTable("store_characteristics")

# COMMAND ----------

# MAGIC %md
# MAGIC OK, so far so good... by what about Synapse data?
# MAGIC
# MAGIC ## Federated queries!
# MAGIC
# MAGIC Databricks Lakehouse Federation is query federation platform that enables you to use Databricks to run queries against multiple external data sources. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lhf_overview.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC In this example we will show how to connect to a dedicated Syanpse Pool via federation, but the same approach can be used for a Synapse serverless endpoint, as well as any of the other data sources listed above. 
# MAGIC
# MAGIC 1. In the Databricks platform, navigate to Catalog on the left menu, then select Add Data and then Add Connection.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lhf_add_connection.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC 2. Select Azure Synapse in the connection type, and fill in all the details as requested and the create the connection. Please note you will only need to do this once for your Synapse database, and it is quite common for this task to be done by a system admin. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lhf_create_connection.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC 3. Once the connection to the Synapse database has been created, multiple catalogs can be created, one per Synapse database. Please note that you only need to know the Synapse database name in order to create a federated catalog now, and you no longer need the connection details for this step. 
# MAGIC
# MAGIC In order to create a federated catalog exposing Synapse, navigate to Catalog on the left menu, then select Add Data and then Add Catalog.
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lhf_create_catalog.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC 4. Fill in the requested catalog details, making sure to select **Foreign** as the catalog type. Select the connection to Synapse that we've just created above (or that someone else might have created for you in your environment) and enter the name of the Synapse database you wish to register.  
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lfg_create_catalog_details.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>
# MAGIC
# MAGIC 5. Once the catalog is registered, you can now find it and query its tables and views and join them to data already in Unity Catalog, just like you would do with any other Unity Catalog tables. 
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="./Images/Lhf_query_synapse.png" alt="Databricks Learning" style="object-fit:scale-down;width:20px;height:30px;">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC