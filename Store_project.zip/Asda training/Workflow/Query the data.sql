-- Databricks notebook source
-- MAGIC %md
-- MAGIC ## Let's query the data!

-- COMMAND ----------

use catalog suppanwo;
use schema supplydatateam;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Which store doesn't open on Sundays?

-- COMMAND ----------


select distinct Store from all_store_details where store not in (select distinct store from all_store_details where day_of_week = 7)


-- COMMAND ----------

-- MAGIC %md
-- MAGIC Which store has the highest revenue?

-- COMMAND ----------

select store, sum(Revenue) as revenue from all_store_details 
group by store order by revenue desc

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Are there any key sale dates for store A1?

-- COMMAND ----------

select * from all_store_details where store = "A1"