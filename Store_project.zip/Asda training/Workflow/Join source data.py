# Databricks notebook source
# MAGIC %sql
# MAGIC use catalog suppanwo;
# MAGIC use schema supplydatateam;

# COMMAND ----------

# MAGIC %md
# MAGIC Create a new table that joins them togther

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC create or replace table all_store_details as 
# MAGIC select sr.*, sc.sqft, sc.coffee from store_revenue sr 
# MAGIC join store_characteristics sc on sr.store = sc.store

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from all_store_details